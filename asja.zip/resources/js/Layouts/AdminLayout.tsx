import { Link, usePage } from '@inertiajs/react';
import { PropsWithChildren } from 'react';

const navItems = [
    { label: 'Testimonies', route: 'admin.testimonies.index' },
    { label: 'Page Content', route: 'admin.component-data.index' },
    { label: 'Blog Posts', route: 'admin.blog.index' },
];

export default function AdminLayout({ children }: PropsWithChildren) {
    const { url } = usePage();

    return (
        <div className="min-h-screen bg-gray-950 text-white flex">
            {/* Sidebar */}
            <aside className="w-64 bg-gray-900 border-r border-gray-800 flex flex-col">
                <div className="p-6 border-b border-gray-800">
                    <span className="text-xl font-bold text-indigo-400">ASJA Admin</span>
                </div>
                <nav className="flex-1 p-4 space-y-1">
                    {navItems.map((item) => (
                        <Link
                            key={item.route}
                            href={route(item.route)}
                            className={`block px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                                url.startsWith(route(item.route).replace(window.location.origin, ''))
                                    ? 'bg-indigo-600 text-white'
                                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                            }`}
                        >
                            {item.label}
                        </Link>
                    ))}
                </nav>
                <div className="p-4 border-t border-gray-800">
                    <Link
                        href={route('home')}
                        className="block text-sm text-gray-500 hover:text-white transition-colors"
                    >
                        ← View Site
                    </Link>
                    <Link
                        href={route('logout')}
                        method="post"
                        as="button"
                        className="mt-2 block text-sm text-gray-500 hover:text-red-400 transition-colors"
                    >
                        Logout
                    </Link>
                </div>
            </aside>

            {/* Main content */}
            <main className="flex-1 overflow-auto">
                <div className="p-8">{children}</div>
            </main>
        </div>
    );
}
