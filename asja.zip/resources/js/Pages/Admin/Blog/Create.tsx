// Admin Blog Create page — wraps the existing full-featured BlogEditor
import BlogEditorPage from '@/BlogEditor/Index';

export default function BlogCreate() {
    return <BlogEditorPage categories={[]} post={null} />;
}
