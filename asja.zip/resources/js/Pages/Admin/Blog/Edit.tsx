// Admin Blog Edit page — wraps the existing full-featured BlogEditor
import BlogEditorPage from '@/BlogEditor/Index';

interface Post {
    id: number;
    title: string;
    content: string;
    cover_image: string | null;
    category: string | null;
    tags: string[] | null;
    is_published: boolean;
    published_at: string | null;
    slug: string;
}

interface Props {
    post: Post;
}

export default function BlogEdit({ post }: Props) {
    // Map BlogPost fields to the format BlogEditorPage expects
    const adaptedPost = {
        ...post,
        featured_image: post.cover_image,
        status: post.is_published ? 'publish' : 'draft',
        category_id: null,
        excerpt: '',
    };

    return <BlogEditorPage categories={[]} post={adaptedPost} />;
}
