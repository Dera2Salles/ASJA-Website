<?php

use App\Http\Controllers\Admin\BlogPostController as AdminBlogPostController;
use App\Http\Controllers\Admin\ComponentDataController;
use App\Http\Controllers\Admin\TestimonyController;
use App\Http\Controllers\LandingPageController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

// ────────────────────────────────────────────────────────────────────────────
// Public routes
// ────────────────────────────────────────────────────────────────────────────

Route::get('/', [LandingPageController::class, 'index'])->name('home');
Route::get('/blog/{slug}', [LandingPageController::class, 'blogPost'])->name('blog.show');

// ────────────────────────────────────────────────────────────────────────────
// Authenticated user profile
// ────────────────────────────────────────────────────────────────────────────

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// ────────────────────────────────────────────────────────────────────────────
// Admin routes (auth required)
// ────────────────────────────────────────────────────────────────────────────

Route::middleware(['auth', 'verified'])->prefix('admin')->name('admin.')->group(function () {

    // Dashboard redirect to first admin section
    Route::get('/', fn () => redirect()->route('admin.testimonies.index'))->name('dashboard');

    // Testimonies CRUD
    Route::get('/testimonies', [TestimonyController::class, 'index'])->name('testimonies.index');
    Route::post('/testimonies', [TestimonyController::class, 'store'])->name('testimonies.store');
    Route::put('/testimonies/{testimony}', [TestimonyController::class, 'update'])->name('testimonies.update');
    Route::delete('/testimonies/{testimony}', [TestimonyController::class, 'destroy'])->name('testimonies.destroy');

    // Component Data (landing page text)
    Route::get('/component-data', [ComponentDataController::class, 'index'])->name('component-data.index');
    Route::post('/component-data', [ComponentDataController::class, 'update'])->name('component-data.update');

    // Blog Posts CRUD
    Route::get('/blog', [AdminBlogPostController::class, 'index'])->name('blog.index');
    Route::get('/blog/create', [AdminBlogPostController::class, 'create'])->name('blog.create');
    Route::post('/blog', [AdminBlogPostController::class, 'store'])->name('blog.store');
    Route::get('/blog/{blog}/edit', [AdminBlogPostController::class, 'edit'])->name('blog.edit');
    Route::put('/blog/{blog}', [AdminBlogPostController::class, 'update'])->name('blog.update');
    Route::delete('/blog/{blog}', [AdminBlogPostController::class, 'destroy'])->name('blog.destroy');
    
    // Students CRUD
    Route::get('/students/view', [\App\Http\Controllers\Admin\StudentController::class, 'view'])->name('students.view');
    Route::get('/students', [\App\Http\Controllers\Admin\StudentController::class, 'index'])->name('students.index');
    Route::post('/students', [\App\Http\Controllers\Admin\StudentController::class, 'store'])->name('students.store');
    Route::put('/students/{student}', [\App\Http\Controllers\Admin\StudentController::class, 'update'])->name('students.update');
    Route::delete('/students/{student}', [\App\Http\Controllers\Admin\StudentController::class, 'destroy'])->name('students.destroy');
});

require __DIR__ . '/auth.php';
