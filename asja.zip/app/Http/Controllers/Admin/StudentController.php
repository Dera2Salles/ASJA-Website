<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;

class StudentController extends Controller
{
    /**
     * Display a listing of the students.
     */
    public function index(Request $request)
    {
        $query = User::where('role', 'Student');

        if ($request->has('search')) {
            $search = $request->input('search');
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('contact', 'like', "%{$search}%")
                  ->orWhere('mention', 'like', "%{$search}%");
            });
        }

        $students = $query->latest()->paginate(10);

        return response()->json($students);
    }

    /**
     * View the Student List page.
     */
    public function view()
    {
        // For Inertia Vue/React
        return Inertia::render('Admin/StudentList/Index');
    }

    /**
     * Store a newly created student in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'lastName' => 'nullable|string|max:255',
            'contact' => 'nullable|string|max:50',
            'password' => 'required|string|min:8',
            'mention' => 'nullable|string',
            'level' => 'nullable|string',
            'branche' => 'nullable|string',
            'Premier' => 'boolean',
            'Deuxieme' => 'boolean',
            'Troisieme' => 'boolean',
        ]);

        $user = new User();
        $user->name = $validated['name'];
        $user->last_name = $validated['lastName'] ?? null;
        $user->contact = $validated['contact'] ?? null;
        $user->password = Hash::make($validated['password']);
        $user->role = 'Student';
        $user->mention = $validated['mention'] ?? null;
        $user->level = $validated['level'] ?? null;
        $user->branche = $validated['branche'] ?? null;
        $user->Premier = $validated['Premier'] ?? false;
        $user->Deuxieme = $validated['Deuxieme'] ?? false;
        $user->Troisieme = $validated['Troisieme'] ?? false;

        $user->save();

        return response()->json([
            'status' => 'success',
            'data' => $user
        ]);
    }

    /**
     * Update the specified student in storage.
     */
    public function update(Request $request, string $id)
    {
        $user = User::findOrFail($id);
        
        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'lastName' => 'nullable|string|max:255',
            'contact' => 'nullable|string|max:50',
            'mention' => 'nullable|string',
            'level' => 'nullable|string',
            'branche' => 'nullable|string',
            'Premier' => 'boolean',
            'Deuxieme' => 'boolean',
            'Troisieme' => 'boolean',
        ]);

        if (isset($validated['name'])) $user->name = $validated['name'];
        if (isset($validated['lastName'])) $user->last_name = $validated['lastName'];
        if (isset($validated['contact'])) $user->contact = $validated['contact'];
        if (isset($validated['mention'])) $user->mention = $validated['mention'];
        if (isset($validated['level'])) $user->level = $validated['level'];
        if (isset($validated['branche'])) $user->branche = $validated['branche'];
        if (isset($validated['Premier'])) $user->Premier = $validated['Premier'];
        if (isset($validated['Deuxieme'])) $user->Deuxieme = $validated['Deuxieme'];
        if (isset($validated['Troisieme'])) $user->Troisieme = $validated['Troisieme'];

        $user->save();

        return response()->json([
            'status' => 'success',
            'data' => $user
        ]);
    }

    /**
     * Remove the specified student from storage.
     */
    public function destroy(string $id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Student deleted successfully'
        ]);
    }
}
