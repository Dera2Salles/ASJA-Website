import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import { Separator } from '@/components/ui/separator';
import {
    SidebarInset,
    SidebarProvider,
    SidebarTrigger,
} from '@/components/ui/sidebar';
import { Link } from '@inertiajs/react';
import { ExternalLink } from 'lucide-react';
import { PropsWithChildren, ReactNode } from 'react';
import { Toaster } from 'react-hot-toast';
import { AdminSidebar } from './Partials/AdminSidebar';

export interface Crumb {
    label: string;
    href?: string;
}

interface Props {
    /** Fil d'Ariane de la page ; le premier niveau est ajouté automatiquement. */
    breadcrumbs?: Crumb[];
    /** Actions propres à la page, alignées à droite de la barre supérieure. */
    actions?: ReactNode;
}

function AdminShell({
    breadcrumbs = [],
    actions,
    children,
}: PropsWithChildren<Props>) {
    return (
        <SidebarProvider>
            <AdminSidebar />

            <SidebarInset>
                {/* Barre supérieure collante : le repère de navigation et les
                    actions de la page restent atteignables au défilement. */}
                <header className="border-border bg-card sticky top-0 z-20 flex h-16 shrink-0 items-center gap-2 border-b px-4 md:px-6">
                    <SidebarTrigger className="-ml-1" />
                    <Separator
                        orientation="vertical"
                        className="mr-1 data-[orientation=vertical]:h-4"
                    />

                    <Breadcrumb>
                        <BreadcrumbList className="text-[13px] font-semibold">
                            <BreadcrumbItem className="hidden sm:block">
                                {breadcrumbs.length === 0 ? (
                                    <BreadcrumbPage className="font-bold">
                                        Administration
                                    </BreadcrumbPage>
                                ) : (
                                    <BreadcrumbLink asChild>
                                        <Link href={route('admin.dashboard')}>
                                            Administration
                                        </Link>
                                    </BreadcrumbLink>
                                )}
                            </BreadcrumbItem>

                            {breadcrumbs.map((crumb, i) => (
                                <span
                                    key={`${crumb.label}-${i}`}
                                    className="contents"
                                >
                                    <BreadcrumbSeparator className="hidden sm:block" />
                                    <BreadcrumbItem>
                                        {crumb.href &&
                                        i < breadcrumbs.length - 1 ? (
                                            <BreadcrumbLink asChild>
                                                <Link href={crumb.href}>
                                                    {crumb.label}
                                                </Link>
                                            </BreadcrumbLink>
                                        ) : (
                                            <BreadcrumbPage className="font-bold">
                                                {crumb.label}
                                            </BreadcrumbPage>
                                        )}
                                    </BreadcrumbItem>
                                </span>
                            ))}
                        </BreadcrumbList>
                    </Breadcrumb>

                    <div className="ml-auto flex items-center gap-2.5">
                        {actions}
                        <a
                            href={route('home')}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="border-border text-foreground hover:border-primary hover:text-primary hidden items-center gap-2 rounded-full border px-4 py-2 text-[12.5px] font-semibold sm:inline-flex"
                        >
                            <ExternalLink className="size-3.5" />
                            Voir le site
                        </a>
                    </div>
                </header>

                <div className="mx-auto flex w-full max-w-[1320px] flex-1 flex-col gap-5 p-4 md:gap-6 md:p-8">
                    {children}
                </div>
            </SidebarInset>
        </SidebarProvider>
    );
}

export default function AdminLayout(props: PropsWithChildren<Props>) {
    return (
        // `app-shell` porte l'habillage « C Vivant » de l'administration :
        // surfaces claires, cartes à 22px, actions en pilule, et la seule
        // zone sombre de l'écran, la barre latérale. Il lève aussi les remises
        // à zéro brutalistes du site public dont dépendent les composants
        // shadcn (ombres, transitions, arrondis).
        <div className="app-shell">
            <Toaster position="top-right" />
            <AdminShell {...props} />
        </div>
    );
}
