import React, { useRef } from 'react';
import { MdPerson } from 'react-icons/md';

interface AvatarProps {
    image: string;
    onCallBack: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export const AvatarUploader: React.FC<AvatarProps> = ({
    image,
    onCallBack,
}) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAvatarClick = () => {
        fileInputRef.current?.click();
    };

    return (
        <div className="flex flex-col items-center gap-2 pb-13">
            <div
                className="group relative cursor-pointer"
                onClick={handleAvatarClick}
            >
                {image ? (
                    <img
                        src={image}
                        alt="Photo de profil"
                        className="size-50 rounded-full border border-gray-200 object-cover transition-all duration-200 group-hover:border-green-400"
                    />
                ) : (
                    <div className="flex items-center justify-center rounded-full bg-gradient-to-br from-zinc-400 to-zinc-500 font-semibold text-white">
                        <MdPerson className="z-100 size-50 p-2" />
                    </div>
                )}
            </div>
            <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={onCallBack}
                className="hidden"
            />
            {image ? null : (
                <p className="font-semibold text-green-700 transition-all duration-500 dark:text-white">
                    Ajouter une photo
                </p>
            )}
        </div>
    );
};
