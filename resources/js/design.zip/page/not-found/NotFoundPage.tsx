import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export const NotFoundPage = () => {
    const navigate = (path: string) => {
        window.location.href = path;
    };

    const goBack = () => {
        window.history.back();
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
            <div className="text-center">
                <h1 className="bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-9xl font-bold text-transparent">
                    404
                </h1>
                <p className="mt-4 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                    Page Not Found
                </p>
                <p className="mt-2 text-gray-500 dark:text-gray-400">
                    Sorry, the page you are looking for does not exist.
                </p>
                <div className="mt-6">
                    <Button
                        onClick={goBack}
                        className="bg-green-500 text-white hover:bg-green-600"
                    >
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Go back
                    </Button>
                </div>
            </div>
        </div>
    );
};
