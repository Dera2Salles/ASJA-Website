export type Level = 'L1' | 'L2' | 'L3' | 'M1' | 'M2';

export type Role = 'Student' | 'Admin';

export type Mention =
    | 'INFORMATIQUE'
    | 'DROIT'
    | 'AGRONOMIE'
    | 'ECONOMIE'
    | 'LANGUE ET CULTURE'
    | 'SCIENCE DE LA TERRE'
    | 'ASJA';

export type Branche =
    | 'GL'
    | 'GI'
    | 'TCO'
    | 'AFFAIRES'
    | 'PROCESSUEL'
    | 'HYDROGEOLOGIE'
    | 'GEOLOGIE MINIERE'
    | 'ECONOMIE ET DEVELOPPEMENT'
    | 'GESTION ET COMMERCE INTERNATIONAL'
    | 'AGROALIMENTAIRE'
    | 'PRODUCTION VEGETALE'
    | 'PRODUCTION ANIMAL'
    | 'COMMUN';

export const mentions: Record<string, Record<string, string[]>> = {
    INFORMATIQUE: {
        L3: [
            "DEVELOPMENT D'APPLICATION INTERNET",
            'TELECOMMUNICATION',
            'GENIE INDUSTRIEL',
        ],
        M1: ['GENIE LOGICIEL', 'TELECOMMUNICATION', 'GENIE INDUSTRIEL'],
        M2: ['GENIE LOGICIEL', 'TELECOMMUNICATION', 'GENIE INDUSTRIEL'],
    },
    DROIT: {
        L3: ['PROCESSUEL', 'AFFAIRES'],
        M1: ['PROCESSUEL', 'AFFAIRES'],
        M2: ['PROCESSUEL', 'AFFAIRES'],
    },
    ECONOMIE: {
        L3: ['GESTION ET COMMERCE INTERNATIONAL', 'ECONOMIE ET DEVELOPPEMENT'],
        M1: ['GESTION ET COMMERCE INTERNATIONAL', 'ECONOMIE ET DEVELOPPEMENT'],
        M2: ['GESTION ET COMMERCE INTERNATIONAL', 'ECONOMIE ET DEVELOPPEMENT'],
    },
    AGRONOMIE: {
        L3: ['AGROALIMENTAIRE', 'PRODUCTION VEGETALE', 'PRODUCTION ANIMAL'],
        M1: [
            'TRANSFORMATION ET CONTROLE QUALITE DES PRODUIT ALIMENTAIRE ',
            'DEVELOPMENT AGRICOLE ET RURALE',
            'PRODUCTION ET SANTE ANIMALE',
        ],
        M2: [
            'TRANSFORMATION ET CONTROLE QUALITE DES PRODUIT ALIMENTAIRE ',
            'DEVELOPMENT AGRICOLE ET RURALE',
            'PRODUCTION ET SANTE ANIMALE',
        ],
    },
    SCIENCE_DE_LA_TERRE: {
        L3: ['HYDROGEOLOGIE', 'GEOLOGIE MINIERE'],
        M1: ['HYDROGEOLOGIE', 'GEOLOGIE MINIERE'],
        M2: ['HYDROGEOLOGIE', 'GEOLOGIE MINIERE'],
    },
    LANGUE_ET_CULTURE: { L3: [] },
};

export const classes = ['L1', 'L2', 'L3', 'M1', 'M2'];

export type Tranche = 'Premier' | 'Deuxieme' | 'Troisieme';

export type Action = 'Creation' | 'Suppression' | 'Modification';
